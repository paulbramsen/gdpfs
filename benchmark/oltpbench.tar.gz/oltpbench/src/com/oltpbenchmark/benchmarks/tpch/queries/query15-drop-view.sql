drop view revenue0;
