DROP VIEW revenue0;
