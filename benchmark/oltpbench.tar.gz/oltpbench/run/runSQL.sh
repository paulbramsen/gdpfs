java -cp `./classpath.sh` -Dprop=$1 -DcommandFile=$2 jdbc.ExecJDBC 
