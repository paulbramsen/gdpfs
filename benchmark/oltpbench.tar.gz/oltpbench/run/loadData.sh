java -cp `./classpath.sh` -Dprop=$1 LoadData/LoadData $2 $3 $4 $5
