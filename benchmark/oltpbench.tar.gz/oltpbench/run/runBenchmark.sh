java -cp `./classpath.sh` -Dprop=$1 client.jTPCCHeadless  --execute true
