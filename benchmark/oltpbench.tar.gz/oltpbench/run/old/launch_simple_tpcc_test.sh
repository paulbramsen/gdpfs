java -cp `./classpath.sh` com.oltpbenchmark.DBWorkload -b com.oltpbenchmark.tpcc.TPCCRateLimited -c config/config.xml -s 1
