java -Xmx1024m -cp `run/classpath.sh` com.oltpbenchmark.DBWorkload -b epinions -c config/sample_epinions_config.xml  --execute true
