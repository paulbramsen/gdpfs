[counts latencies monitor] = fast_deverticalize_align('./test1/', './test1/', 'transactions.csv','log_exp_1.csv', 1, 6);
