FIG Tree
========
The **F**ile **I**ndexed-**G**roups **Tree** is an index for a file split into contiguous groups.

This is a C implemenation of a FIG tree. See https://github.com/samkumar99/fig-tree for a description of the algorithm and an implementation in Java.